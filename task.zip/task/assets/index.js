$(document).ready(function(){

  $('#form_file').on('submit', function(e){

    // Blocco il submit di default del form
    e.preventDefault();

    // Carico dati del file
    var file_data = $('#file_csv').prop('files')[0];

    // Se i dati sono presenti proseguo altrimenti avviso
    if(file_data){

      // Estraggo estensione file
      var extension = file_data['name'].substr( (file_data['name'].lastIndexOf('.') +1) );

      // Se l'estensione è CSV proseguo altrimenti no
      if(extension == 'csv'){

        // Associo i dati a quelli del form da inviare
        var form_data = new FormData();
        form_data.append('file', file_data);

        $.ajax({
          'type': 'POST',
          'dataType': 'JSON',
          'url' : 'scripts/report.php',
          'processData': false,
          'contentType': false,
          'data': form_data
        }).done(function(data){

          // Se trovo una tabella da mostrare lo faccio altrimenti errore
          if(data.msg != ''){
            $('#table_show').html(data.msg);
            $('#file_csv').val('');
          }else{
            $('#file_csv').val('');
            $('#table_show').html(data.page);
          }

        });
      }else{
        alert("Estensione file errata, carica un file .csv");
        $('#file_csv').val('');
      }
  }else{
    alert("Seleziona un file da caricare");
  }

  });



});

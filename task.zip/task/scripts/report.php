<?php
include('../models/Customer.php');
include('../models/CurrencyConverter.php');

$customer = new Customer();
$currency_converter = new CurrencyConverter();

// Carico il file .csv e ne faccio il parsing
$transactions = $customer->getTransactions($_FILES['file']['tmp_name']);
$i = 1;

if($transactions['msg'] == ''){

  //TODO print formatted report

  // Inserisco titoli colonne
  $page_content ='<div class="page-header text-center">
                  <h2>Risultato elaborazione</h2>
                  </div>';
  $page_content .= '<table class="table table-dark"><thead>';
  $page_content .= '<tr>';
  $page_content .= '<th scope="col">'.strtoupper(str_replace('"', '', $transactions['titoli'][0])).'</th>
                    <th scope="col">'.strtoupper(str_replace('"', '', $transactions['titoli'][2])).'</th>
                    <th scope="col">'.strtoupper("Old").'</th>
                    <th scope="col">'.strtoupper("Ex. Rate").'</th>
                    <th scope="col">'.strtoupper(str_replace('"', '', $transactions['titoli'][1])).'</th>
                    </tr>';
  $page_content .='</thead>';

  $i++;

  foreach ($transactions['valori'] as $transaction) {

      $customer = $transaction['CUSTOMER'];

      // Estraggo valore pre-conversione
      $old_amount = str_replace('"', '',$transaction['VALUE']);

      // Estraggo i valori dopo il parsing del csv, converto l'amount tramite la classe Currency converter - metodo convert
      $amount_extract = $currency_converter->convert($transaction['VALUE']);

      // Se una delle conversioni va in errore lo restituisco
      if($amount_extract['msg'] != ''){
        die(json_encode(array('page' => '', 'msg' => $amount_extract['msg'].' sulla riga: '.$i)));
      }

      // Creo amount modificato con simbolo Euro
      $correct_amount = $amount_extract['converted_amount'];

      // Se ex rate diverso da -1 (ovvero Euro su Euro), lo restituisco nel report
      $ex_rate = ($amount_extract['ex_rate'] == -1) ? 0.00 : $amount_extract['ex_rate'];

      // Tolgo "" dalla data
      $date = str_replace('"', '', $transaction['DATE']);

      $page_content .= '<tbody><tr>';
      $page_content .= '<td>'.$customer.'</td>'.
                       '<td>'.$correct_amount.'</td>'.
                       '<td>'.$old_amount.'</td>'.
                       '<td>'.number_format($ex_rate,'2', '.', ',').'</td>'.
                       '<td>'.$date.'</td>';
      $page_content .= '</tr></tbody>';

      $i++;
  }

  $page_content .='</table>';

  die(json_encode(array('page' =>$page_content, 'msg' => '')));

} // Se non sono riuscito a fare il parsing ritorno l'errore
else{
  die(json_encode(array('page' => '', 'msg' => $transactions['msg'])));
}

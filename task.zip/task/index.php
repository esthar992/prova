<html>
<head>
  <title> Convertitore valute da CSV </title>

  <!-- Jquery CDN-->
  <script src="https://code.jquery.com/jquery-3.5.1.min.js" integrity="sha256-9/aliU8dGd2tb6OSsuzixeV4y/faTqgFtohetphbbj0=" crossorigin="anonymous"></script>

  <!-- BOOTSTRAP CDN-->
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

  <!-- index.js -->
  <script src="assets/index.js"></script>

</head>
<body>
  <div class="container">
    <div class="page-header text-center">
     <h1>Convertitore valute da CSV</h1>
    </div>

    <div class="row">

     <div class="col-sm"></div>
     <div class="col-sm">
      <form class="text-center" id="form_file" name="form_file" enctype="multipart/form-data" method="post" action="">
      <div class="form-group">
       <input type="file" class="form-control-file" name="file_csv" id="file_csv" placeholder="Scegli un file .csv">
      </div>
       <button type="submit" id="invia" name="invia" class="btn btn-primary">Invia</button>
     </form>
    </div>
    <div class="col-sm"></div>

   </div>
</div>

 <!-- Contenitore tabella -->
 <div class="row">
  <div class="col" id="table_show"></div>
 </div>
</body>
</html>

<?php

class Customer
{
    public function getTransactions($file_name)
    {
      $righe_headers = [];
      $righe_valori = [];
      $i = 0;

      // Leggo il contenuto del file
      $file = file_get_contents($file_name);

      // Se non sono riuscito a leggere il file ritorno errore
      if($file){

        // Divido le righe del file in un array
        $file_ex = explode(PHP_EOL, $file);

        // Ciclo riga per riga
        foreach($file_ex as $riga){

          // Se è la prima riga assegno gli header all'array $righe_headers
          if($i == 0){
            $titoli_ex = explode(';', $riga);
            $righe_headers = $titoli_ex;

            // Incremento contatore riga
            $i++;
          }
          // Altrimenti associo i valori all'interno di un array associativo e vado avanti
          else{

            if(!empty($riga)){
              $riga_ex = explode(';', $riga);
              $righe_valori[$i]['CUSTOMER'] = $riga_ex[0];
              $righe_valori[$i]['DATE'] = $riga_ex[1];
              $righe_valori[$i]['VALUE'] = $riga_ex[2];

              // Incremento contatore di riga
              $i++;
            }
          }

        }

      return array('titoli' => $righe_headers, 'valori' => $righe_valori, 'msg' => '');
    }
    else{
      return array('titoli' => '', 'valori' => '', 'msg' => 'Errore lettura file');
    }
  }

}

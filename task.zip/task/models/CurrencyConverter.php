<?php

/**
 * Uses CurrencyWebservice
 *
 */
class CurrencyConverter
{

    public function convert($amount)
    {
      $currency = '';

      // Effettuo il trim per rimuovere eventuali spazi tra valuta e valore
      $amount_trimmed = trim($amount);

      // Divido ammontare e valuta per passarlo all'api tasso di cambio
      // se la divisione non riesce ritorno messaggio di errore
      $amount_and_currency = $this->split_amount_currency($amount_trimmed);

      if($amount_and_currency['msg'] == ''){

        // Controllo che nell'amount sia presente un simbolo di valuta
        $check_currency = $this->check_currency($amount_and_currency['currency']);

        if($check_currency['msg'] == ''){

          // Setto chiamata CURL GET per leggere il valore di ritorno del tasso di cambio
          // l'url coincide con quello del resto dell'applicazione dato che il file dell'api è nella stessa cartella
          $curl = curl_init();
          curl_setopt($curl, CURLOPT_URL, $_SERVER['HTTP_HOST'].'/task/models/CurrencyWebservice.php?currency='.$amount_and_currency['currency'].'&key=abcdef');
          curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);

          $response = json_decode(curl_exec($curl));

          curl_close($curl);

          if($response->msg == ''){

            // Estraggo il tasso di cambio
            $exchange_rate = $response->ex_rate;

            // Calcolo il nuovo ammontare basandomi sul tasso di cambio, se è -1 significa che il costo è già in Euro
            // e non va modificato
            $converted_amount = ($exchange_rate != -1)
                                ? number_format($amount_and_currency['value'] * $exchange_rate, 2, '.', ',')
                                : number_format($amount_and_currency['value'], 2, '.', ',');

            // Associo la valuta Euro all'ammontare
            $converted_amount_with_currency = '&euro;'.$converted_amount;

            // Ritorno il tutto
            return array('converted_amount' => $converted_amount_with_currency, 'msg' => '', 'ex_rate' => $exchange_rate);

          } // chiamata API fallita
          else{

            return array('converted_amount' => 0, 'msg' => $response->msg, 'ex_rate' => 0);

          }
       } // Valuta non presente
       else{
        return array('converted_amount' => 0, 'msg' => $check_currency['msg'], 'ex_rate' => 0);
       }
     } // Valuta e/o numero non presente
      else{

        return array('converted_amount' => 0, 'msg' => $amount_and_currency['msg'], 'ex_rate' => 0);

      }

    }


    // Metodo che controlla che nell'amount sia specificata una valuta
    private function check_currency($value){

      $currencies = ['$', '€', '£'];
      $matches = [];

      foreach($currencies as $currency){

        if($currency == $value){
          array_push($matches, $value);
        }

      }

      // Se il count della differenza tra l'array currencies e quello dei match della valuta
      // è uguale al numero di valute esaminate, nessuna è stata trovata e ritorno errore.

      return (count($matches) == 0)
             ? array('msg' => 'Valuta non specificata')
             : array('msg' => '');
    }


    // Metodo che ritorna due valori distinti in un array, valuta e valore
    private function split_amount_currency($value){

       // Preparo due regexp per trovare valuta e ammontare
       $amount_regexp   = "/[0-9\.]+/";
       $currency_regexp = "/[£\$€]+/";

       // Cerco i match nella stringa e li divido
       $amount_match = preg_match($amount_regexp, $value, $match);
       $currency_match = preg_match($currency_regexp, $value, $match_currency);

       // Se trovo match sia per la valuta che per l'ammontare ritorno i valori altrimenti errore
       if(count($match)!= 0 && count($match_currency) != 0){
         return array('value' => floatval($match[0]), 'currency' => $match_currency[0], 'msg' => '');
       }
       else{
         return array('value' => 0, 'currency' => '', 'msg' => 'Formato ammontare non valido');
       }

    }
}

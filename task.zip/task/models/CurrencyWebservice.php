<?php

// Simulo gli header per accettare chiamate da qualsiasi origine, come se fosse una vera API
// l'output è in JSON, simulando il normale comportamento di un'API.
header('Access-Control-Allow-origin: *');
header('Content-Type:application/json');

/**
 * Dummy web service returning random exchange rates
 *
 */
class CurrencyWebservice
{
    /**
     * @todo return random value here for basic currencies like GBP USD EUR (simulates real API)
     *
     */

    // Controllo nel metodo la presenza di un'api key corretta
    // Potrei mettere l'api key all'interno di un file di configurazione o nel caso avessimo avuto un DB con n chiavi attive
    // avrei eseguito una query sullo stesso per verificarne la validità.
    public function getExchangeRate($currency, $api_key)
    {
     if($api_key == 'abcdef'){

        $ex_rate = 0;

        if($currency == '€'){
          $ex_rate = -1;
        }
        if($currency == '£'){
          $ex_rate = 2.50;
        }
        if($currency == '$'){
          $ex_rate = 3.00;
        }

        // In caso affermativo ritorno il tasso di cambio altrimenti un messaggio di errore
        return ($ex_rate != 0)
        ? json_encode(array('ex_rate' => floatval($ex_rate), 'msg' => ''))
        : json_encode(array('ex_rate' => 0, 'msg' => 'Valuta non specificata o non esistente'));
      }
      else{
        return json_encode(array('ex_rate' => 0, 'msg' => 'Api key errata'));
      }
    }
  }


// In base al request method chiamo uno specifico metodo di currency webservice.
// Nel caso in cui avessimo piu' metodi, suddividerei l'url per vedere il numero di parametri passati
// in modo da eseguire chiamate diverse a metodi diversi, per ora supporta solo GET per leggere il cambio valuta.
// - - - - - - -
// Inoltre, potrei spostare tutta la logica di chiamata e di switch in altri file, per creare degli url piu' friendly
// Quindi ad esempio questa parte può andare in un file chiamato ExchangeRate.php, includendo la classe al suo interno
// Ma essendoci una sola chiamata possibile lo lascio qui.
$CurrencyWebservice = new CurrencyWebservice();

switch($_SERVER['REQUEST_METHOD']){

  case 'GET':
    echo $CurrencyWebservice->getExchangeRate($_GET['currency'], $_GET['key']);
  break;

  default:
    echo json_encode(array('ex_rate' => 0, 'msg' => 'Metodo '.$_SERVER['REQUEST_METHOD'].' non supportato'));
  break;

}
